# 独立 representation reconciliation semantic authority

本 Bundle 自包含。仅使用其中输入，不扫描 repository。唯一问题：question.json 的冻结 reviewed_target，能否作为同一 source_text 及整篇 source 实际上下文的可信语义对应，保持旧 reviewed A translation 的全部字节不变？

必须区分 Go identifier/API 的 exact identity 与普通自然语言概念。不要仅因中文缺少 literal 就自动批准或拒绝；结合整个 source、旧 reviewed candidate、glossary、old/current protection 和精确 changed atoms 判断。所有机器证据成立不代替本语义判断。

只作独立语言 authority 决定：APPROVE_RECONCILIATION 或 REQUIRE_LANGUAGE_REVISION，附 exact finding/reason。不是新 QC，不给 A/B/C/D，不生成 replacement，不修改 candidate，不建议猜选 target 位置。批准只授权 question 的整个冻结 prose 区间，不能豁免 URL、code、binding 或其它 machine identity。拒绝则保持 representation-only blocked，后续走正式 finding-anchored exact revision。

从 manifest.json 复制 identity 至 bundle_identity，并从 Local terminal handoff 复制 ZIP SHA 至 bundle_sha256。在 decision-template.json 的其它已填 identity/provenance 字段中保留 frozen 值；填写 generation_independent=true（真实独立性声明）、真实 reviewer_session、provider=chatgpt、model=gpt-5.6-sol-high、decision、finding。只输出这一 JSON，不增加 replacement、rating 等字段。Reviewer session 必须与该 locale 全部 Generation session 独立。Local terminal 用 current-check 和 record 记录 immutable evidence；本 Bundle 导出不记录决定，不改变 formal state。
