# Versionless Locale / Site v2 Workflow Foundation

所有正式翻译单元的执行以[共享翻译单元生命周期与五角色协作](SHARED_TRANSLATION_UNIT_LIFECYCLE.md)为共同 authority。Tour、Learn/Docs 和未来内容包共用 `internal/i18n` 的成熟状态机；本文件仅定义页面适配和内容包后续边界，不授权平行 Generation/recovery/retry/QC/finalization。

本文是 V2-D 的 executable contract。v1/v2/v3 是 implementation/content-package/source-contract milestone，不是 locale language governance namespace。**Content package 可以版本化；Locale language system 不版本化。** package 划分 source、coverage、completion、activation 与 reuse，不划分 glossary、locale identity、术语治理、Generation/Reviewer session 或 provenance。

## Full locale Preview runtime composition

`preview --locale` 在原 exact-current Tour Surface A gate 和 Tour projection 后，通过 `internal/site.LoadContent` + `Content.Compose` 组合 runtime。Site 页面只消费 current completed package 的 reconstructed bytes；正式 metadata、HTML / Markdown、Learn template / localized YAML 分别解析后渲染。`/tour/**` 的 canonical 页面和必要静态资源、lesson、Playground HTTP endpoints 保留原 Tour handler；其他页面、alias、true 404、canonical 与 sitemap 共用 Site Resolver，不注册 Tour SPA 全路径兜底。coverage navigation 与直接 HTTP 请求分开：未覆盖目的地链接 go.dev，未覆盖本地请求返回 404。

Preview sitemap 的 exact set 来自 current `locales/<locale>/content-scope.json`，runtime 先验证其 completion evidence。三个 package 全部 current complete 时仍为 156 条（Tour 105、Learn/Docs 49、shell 2）；full Homepage/shared chrome adoption 不扩大 route coverage。旧 shell completion 在 adoption 后仅为 historical predecessor；缺新 Homepage A-only + 四份 structured + translation exact carry 时，runtime 在监听前 fail closed，不能发布简化 home.html。

此 composition primitive 可供后续 release adapter 复用，但本次只接入 full-locale Preview。现有 `publish`、Tour Production runtime、`verify-production.sh` 的 105 条 release contract 仍属于独立 Site v1 路径，不读取或复用此 activated Site sitemap。后续 Site v2 Production activation 必须整体接入同一 Resolver / completed content，并同步 release projection、verifier 和 runbook；本节不授权 publish、deploy 或 successor activation。

## Source 与统一 terminology authority

pre-V2-C1 正式 English authority 是主动冻结的 `golang/website@db076098077c07d3cef1b85a2cf56ff52777f587`，不是 latest upstream。campaign / Preview / Production 不被 deferred C1 阻塞，不增加联网 drift gate。四个 tracked issue 达到维护者预期且显式重开后，仅一次 C1 sync；此处不执行 sync。

原 `data/site-content-scope.json` 保留 historical package closure；repo-local frozen source authority 保留 49 Page + 7 data = 56 Learn/Docs localizable documents。shell current adoption 投影 `_content/index.md` 的一个 Homepage Page TU、四份 shared structured source、既有 translation.html，canonical 仍仅 `/` 与 `/translation/`。home.html 仅 historical predecessor。详细 authority 与 CAS 见 [Shell current adoption](SITE_SHELL_SUCCESSOR_AUTHORITY.md#current-adoption六份原子-closure-与-jit)。

唯一 locale glossary：`locales/<locale>/glossary.yaml`。mandatory/preferred/forbidden/keep 四类不变，禁止 Tour/Docs/Learn/v2/v3/core/extension/shadow glossary。

Unified Glossary Source Corpus authority 是 `data/glossary-source-corpus.json`，contributors 同时是 shared structured source registry。foundation v1 曾投影 103 Tour Page、19 eligible Example、113 UI values、7 article headers、103 SEO descriptions、两个简化 shell source、7 Learn YAML、49 Learn/Docs Page（当时 403 contributors/3,004 contexts）。随后 v2 terminology discovery 与 shell corpus successor 已正式应用；当前 exact membership/count/identity 以 JSON 和完整 Unified Review 为准，包含 full Homepage 与四份 shared structured source，retire old home contributor。binary/machine-only代码不作为语言文本；protected technical context 保留只读。future surface additive 注册并使用正式 parser，不另建 glossary generation。

仓库已具备但当前尚未应用 terminology-discovery lifecycle。`site-content terminology-authority --website-root <clean-pinned-checkout> --go-source-archive <pinned-archive>` 默认只做离线 dry-run；显式 `--apply --prior-sha256 <current-corpus-file-sha256>` 才以 CAS 创建/刷新 `data/terminology-discovery-sources.json`、`.zip` 并把 unified corpus 升为 `go-learning/glossary-source-corpus/v2`。已有 discovery manifest 再刷新还必须提供 `--prior-terminology-sha256 <current-manifest-file-sha256>`。普通 `site-content terminology-check` 完全离线：未应用时验证合法 `not-applied` v1 状态；应用后从 snapshot 重建 projection 并对 manifest/parser/corpus drift fail closed。它不联网、不写 locale evidence，也不执行 V2-C1。

v2 contributor 显式使用 `purpose=active-content|terminology-discovery`。现有 Tour/UI/article/SEO/shell/Learn/Docs 全部是 active-content；冻结 website / Go source contributor 是 terminology-discovery、`structured=false`，不得形成 package、coverage、route、completion、runtime 或 locale structured output。raw manifest/snapshot identity 证明冻结输入 bytes；unified corpus identity只绑定 deterministic language projection，因此 machine-only raw bytes变化不会冒充 projected terminology变化。两类 purpose 仍共同进入唯一 corpus identity，不存在 discovery-only glossary、Review receipt 或 compatibility shortcut。

Corpus identity只绑定 deterministic contributor language/context projection；raw source file hashes另外负责机械 current-check，不把 image/code-only raw bytes变化等同于 terminology变化。`site-content corpus-check` 重建实际projection并比较；unknown parser/metadata/contributor、wrong hash、UTF-8、duplicate/unknown/trailing JSON、traversal/symlink fail closed。没有 AI术语抽取阶段。

## 一次 unified Glossary Generation / Review

新 locale：一次完整 Glossary Generation；existing locale：保留既有 glossary、一次 Unified Glossary Refresh。都输出完整 `glossary.yaml`，允许 byte-identical；不输出surface extension fragment。future sync跨Tour/Docs/future scope合成一次 corpus delta、最多一次 locale refresh。

```sh
go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-export --locale <locale> --task glossary --output /tmp/<locale>-glossary-generation.zip
go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-check --bundle /tmp/<locale>-glossary-generation.zip
go run -mod=readonly ./cmd/tour-i18n glossary-review reviewer-bundle --locale <locale> --output /tmp/<locale>-glossary-reviewer.zip
go run -mod=readonly ./cmd/tour-i18n glossary-review reviewer-bundle-check --locale <locale> --bundle /tmp/<locale>-glossary-reviewer.zip
go run -mod=readonly ./cmd/tour-i18n glossary-review record --locale <locale> --review-id <id> --reviewer <independent-session> --generation-session <generation-session> --decision passed --bundle /tmp/<locale>-glossary-reviewer.zip
go run -mod=readonly ./cmd/tour-i18n glossary-review check --locale <locale> --coverage unified
```

transport `go-learning/unified-glossary-bundle/v1` 绑定完整 corpus、完整 glossary/skeleton、locale identity、terminology/review authority、exact outputs、input identity；Reviewer role没有replacement输出。新 receipt `go-learning/unified-glossary-review/v1` 保存完整 glossary path/SHA、corpus identity、archived Reviewer ZIP SHA/input identity、review ID、Reviewer/Generation session、decision/rubric/findings与self identity。ZIP与review evidence immutable、hash-bound。

old v1 receipt与fixed legacy coverage继续保持 Tour historical/current coverage。exact current unified Review优先；旧receipt不参与unified ambiguity。多个current unified receipts fail closed。无unified时旧Tour completion仍可合法验证；新语言工作要求current unified PASS。glossary任意byte change或corpus identity change均使旧unified Review stale；byte-identical refresh也不能拿Tour-only receipt冒充new corpus coverage。没有 corpus compatibility shortcut。

terminology-discovery authority 一旦在安全 workflow boundary 显式应用，哪怕 `glossary.yaml` bytes 最终不变，新 corpus identity 仍使旧 unified receipt 自然 stale，必须由独立 Reviewer 对单一完整 glossary 执行 full Unified Review。discovery corpus只降低未来 glossary churn 的预期，不降低审核范围或 A-only downstream gates。若 future package 没有 governance-significant terminology，refresh 可 byte-identical 但仍 full Review；若存在新术语/collision，则 Generation 刷新单一完整 glossary，full Review PASS 后才执行 compatibility assessment 并只 reopen真实 affected scope。不得按 Page 数量机械扩 glossary。

glossary改变之前归档原bytes；new full unified PASS之后，V2-B archived old/new → semantic delta → exact affected scope → immutable compatibility lineage。Docs-only term不会自动重翻旧Tour Page；shared core term只reopen真实affected TU/asset。unknown impact fail closed；历史A、Snapshot、glossary Review、Surface与provenance不改写。

## Unified Structured Assets

contract `go-learning/locale-structured-assets/v1` 使用 corpus contributor 的 structured 属性。adoption 后为 14 个完整资产：Tour UI、article metadata、四份 shell shared structured、translation body、7 Learn YAML；Homepage body 是独立的一个 shared Page TU，不混入 structured outputs。existing locale 沿用真实 accepted baseline、current source/target/glossary assessment；Expected 仅当前正式调度的 exact generation-required outputs。JIT 先 Homepage TU，再 current structured composite Bundle。

```sh
go run -mod=readonly ./cmd/tour-i18n site-content structured-plan --locale <locale>
go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-export --locale <locale> --task locale-assets --output /tmp/<locale>-structured.zip
go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-check --bundle /tmp/<locale>-structured.zip
go run -mod=readonly ./cmd/tour-i18n site-content structured-import --bundle <repo-relative.zip> --input <repo-relative.json> --provider <chatgpt|codex> --model gpt-5.6-sol-high --session <generation-session> --generated-at <UTC>
```

模型只输出plan.Expected exact set，不重新输出carry。Tour UI/metadata使用原schema validator；shell/YAML输出完整slot target set，受parser重建，不允许任意目录绕过保护。composite evidence记录一个真实Generation session/provenance，subassets仍保持source/target/package/validator边界。structured asset不另建逐-TU QC；finding回原Generation → exact replacement → validation → affected Surface re-review。

### Structured Generation stale-Bundle carry-forward

正常 structured import 仍要求 Bundle current-check 与 output 绑定实际输入 identity。首次模型输出已完成、但旧 Bundle 后来 stale 时，新 Bundle + 改写原 JSON identity 会伪造 model input；普通 TU recovery 不能表达 structured scope。这一证据缺口通过既有 `StructuredGeneration` 的可选 `carry_forward` successor edge 表达，不新增平行 Generation/retry/Review 状态机，也不作为语言 acceptance。

`site-content structured-recover` 默认只读 preflight；正常 preflight/apply 都由 Maintainer Local terminal 执行。必须提供原 Bundle/output 的可信 SHA 和完整原 provider/model/session/generated_at。实现验证旧 Bundle transport inventory、self identity、Plan self identity、StrictJSON 与原 output → old Bundle identity；重导并 current-check 当前 canonical Bundle，比较完整 Plan（包括 Expected、source/Document/slot/protection/target path、Review/glossary/corpus/assessment/finding），并逐字节比较全部非 execution transport members。Plan identity 不单独作为兼容证明。最后原 output 通过 current canonical reconstruction/schema/glossary validation；任何真实漂移、未知 legacy authority 或 validator failure 均 fail closed，需要真实 re-Generation 或进一步工程诊断，不能强行 carry。

`structured-language/v1` 的语义依赖是 `STRUCTURED_GENERATION_SEMANTICS.md`、`TRANSLATION_TERMINOLOGY.md` 与 `TERMINOLOGY_GUIDE.md`，连同 source、glossary、locale、corpus、完整 independent Unified Review、predecessor/finding 等正式输入决定 currentness。原 PackageAuthorities 完整文档继续随 Bundle 运输、受 inventory/hash 保护，但其 execution/tooling 说明不再是额外 language-semantic authority；语言规则必须在上述正式语义 contract 修改，不能通过执行手册覆盖。语义文件任意 byte drift 仍 stale。未分类 legacy Bundle 只接受实现中经审计的 exact legacy authority SHA → exact new semantic authority SHA 桥接；未知版本不能凭 `.md` 或 docs-only 声明自动兼容。

apply 将原 Bundle、原 output JSON 原始字节与 current checked Bundle 保存为既有 content-addressed immutable archives，再保存新的 StructuredGeneration successor。其 `bundle` 与 `output.bundle_identity_sha256` 仍指真实原模型输入；`generation` 保留原 provenance，绝不使用 recovery 时间；`carry_forward` 绑定原 output archive/current Bundle/authority edge 与 reconstructed target hashes。只有最后的 generation evidence 保存后才宣告 applied；partial content-addressed archives 不等于正式 import 成功，禁止覆盖历史 failure。closure/Surface 沿用既有 `--generation` 引用和 readers，重新验证原字节、冻结 lineage 与当前 source/semantic authority/glossary/validators。historical integrity 不要求今天 Plan 仍待生成，不改写旧 judgment；本 recovery 不执行 closure、Surface 或 activation。

```sh
go run -mod=readonly ./cmd/tour-i18n site-content structured-recover \
  --bundle <original-bundle-path> --input <original-output-path> \
  --bundle-sha256 <trusted-original-bundle-sha256> \
  --output-sha256 <trusted-original-output-sha256> \
  --provider <original-provider> --model <original-model> \
  --session <original-generation-session> --generated-at <original-generated-at>
# 同一可信输入 preflight PASS 后，由 Local terminal 加 --apply 保存 successor。
```

### Structured historical baseline 与当前精确 delta

**historical completion ≠ current eligibility**。旧 completion 先通过冻结输入下的 historical integrity：generation 与 Bundle hash/input identity、完整旧 Unified Review 及其 Reviewer archive、旧 glossary、真实 provenance/session、精确 source/parser/structure、outputs/reconstruction/validator，以及 closure 的完整 localized inventory/self identity。此步骤不要求旧 glossary 今天仍 compatible，不修改旧 evidence，不 mass migrate。

正常路径为 **historical baseline → per-asset current assessment → exact glossary-affected Generation delta → current closure → delta-aware Integrated Surface review**。`structured-plan` 对 completed package 逐 asset 绑定 baseline closure/generation/Surface、accepted target、旧/当前 glossary、当前完整 Unified Review、精确 source/input 与 assessment self identity；使用共享 `ParsedGlossaryDelta` / `ParsedGlossaryImpact` 和当前 reconstruction/validation，返回 compatible（carry）、affected（generation-required）、stale 或 unknown。stale/unknown 禁止 Bundle 导出与 closure；未知或尚只有 source foundation、缺 lifecycle reconstruction/validator 的 parser 不能成为 Generation 任务。

completed baseline 存在 affected 时，`Expected` 只包含其 exact affected outputs；其他未启动 package 的 initial outputs 保留 context-only，不混入本次 reopening invocation。导出的既有 Structured Bundle 包含 hash-bound baseline evidence/Generation archive、完整当前 glossary/Review、当前 source 与 predecessor slots/旧 glossary。current checker 必须重建相同 Bundle；import 仍绑定实际读取的 input identity、真实 Generation provenance、精确 outputs 和现有 validator。glossary delta 使用 assessment authority，不能伪造 Surface finding。

`package-closure` 的 repeatable `--generation` 可组合 baseline generations 与唯一 exact affected delta。compatible 只能 carry；affected 缺 replacement、compatible 任意 replacement、多余/重复/冲突 delta、错误 baseline/package/glossary/input/provenance、非完整 inventory 均 fail closed。closure 的可选 `structured_baseline_closure` 绑定被替换的历史 closure；`CheckPackageClosure` 下游重新验证整个合并，不信任已保存的通过状态。原 Page A-only finalization/current authorization 独立消费，structured glossary delta 不 reopen、regenerate 或重新 rating 无变化 TU。

Integrated Surface 根据同一 baseline/delta proof 处理范围：delta structured asset 进入 review-required（即使 bytes 恰好相同也要审核）；原 exact accepted target/source 及 prior Surface 支持的 unchanged structured assets、unchanged finalized Page 进入 carry。发生真实变化的 Page 仍消费共享 QC/authorization，不由 structured assessment 产生语言 A。global/Tour planner 不要求其他 package 的 historical structured completion 先通过 current closure；各 package 的 current eligibility 独立判定。

Course SEO是Page-derived consumer，canonical English description + final ready Page + glossary决定scope；不强行并入initial structured generation。existing current Tour SEO carry；本轮没有正式Learn/Docs canonical SEO source authority，不生成虚假SEO contract。future canonical consumer接同一locale/provenance/compatibility framework。

## 完整 Page TU / internal slots / fixed batching

internal parser `go-learning/content-units/v2` 保留Markdown Goldmark AST、HTML tokenizer、窄Learn YAML schema；internal linguistic slots用于保护、精确impact、deterministic restoration与reconciliation，**不是formal TU**。当前56 documents有2,646 internal slots；min/median/p90/max = 2/84/269/691 UTF-8 bytes，<=20=383，punctuation-only=0；最大gomod-ref 207 slots。slot packing仅internal diagnostic，CLI summary明确标记diagnostic，不是模型调用plan。

正式页面表示保留 `go-learning/page-translation-unit/v1`；旧 `go-learning/package-workflow/v2` 仅用于历史证据读取与原 JSON 导入兼容，不继续复制审核或终结状态机。49 个物理页面就是49个正式页面翻译单元；embedded CodeExample=0，7 个结构化数据资产不进入逐单元质量审核。完整页面受保护输入通过块边界与行内绑定还原，一个页面一个候选及 A/B/C/D 评级。安全 Go 教学代码注释仍属页面；复用 Tour 保守片段分析器，代码身份、分隔符、布局和未知代码受保护。标题后缀、行内代码、Markdown 链接地址与标签绑定完整保留，可合法移动完整行内绑定，不能移动页面结构边界。

Page 重建逐 source coordinate 校验 protected token membership、pair/suffix 并恢复原始 bytes；内部 fragment 可为空或只剩标点，语言完整性由完整 Page 的独立 QC 判断。target 不重新参与 source teaching-comment eligibility 或 language-slot discovery；新增未保护 syntax/换行仍拒绝，Markdown heading/list/table/code 等 enclosing structure 仍验证，合法 soft-wrap token 的位置不绑定 prose paragraph segmentation/list tightness。Markdown emphasis delimiter 按 Goldmark 的实际匹配与 source binding 保护，内部自然语言不因 closing underscore 被误判为 machine atom。protector input/ID 真实变化时旧 bundle stale；只保留 exact input/ID 未变且重新验证通过的旧 target bytes，不改写旧 bundle/result 或 provenance。

stable append-only Page authority：`data/learn-docs-pages.json`，schema `go-learning/stable-page-index/v1`。首次按learn/tutorial/database/modules/security，surface内path lexical order冻结1–49。future append50–60进入batch2；delete tombstone不复用；move/rename必须explicit mapping，unknown/ambiguous不猜。index61 fail closed，交维护者决定batching authority，不自动第三批、不rebalance。

正式initial Generation与QC各两次独立invocation：

| batch | stable membership | current Page count | raw source/context bytes |
| --- | --- | ---: | ---: |
| page-batch-1 | 1–30 | 30 | 267,539 |
| page-batch-2 | 31–60 | 19 | 150,854 |

initial Generation / initial QC 每组最多30 Page；通用60 defensive ceiling不授予合并 initial 两组。两批初审完整结束后，正式 B/C/D 与 Surface reopen exact revision 可跨 initial membership，只受共享同 kind、最多60及正式 scope/identity/finding 等 gate 约束。successor re-QC 按 current `quality_check_required` pending、stable index顺序、同 kind、最多60选择，record语义一致，多组继续JIT。glossary-stale recovery保留既有固定分组；retry/recovery不变。transport safety与阶段调度分开，现有16 MiB text/context/output等transport hard safety limit不变；超出停止、报告evidence，不自动拆成几十组。

```sh
go run -mod=readonly ./cmd/tour-i18n site-content page-plan --package learn-docs-v1
go run -mod=readonly ./cmd/tour-i18n site-content generation-plan --locale <locale> --package learn-docs-v1
go run -mod=readonly ./cmd/tour-i18n retranslation progress --locale <locale> --content-package learn-docs-v1
go run -mod=readonly ./cmd/tour-i18n retranslation export --locale <locale> --generator chatgpt --content-package learn-docs-v1
# batch ID 使用真实 export 输出；后续 generation-bundle export/check/import 与 process/retry
# 均使用既有共享命令，并传 --content-package learn-docs-v1。
```

调度固定为第一批生成 → 精确重试至30/30 → 第二批生成 → 精确重试至19/19 → 完整49页候选快照 → 第一批初审 → 第二批初审 → 汇总全部 B/C/D → 共享精确修订 → 独立再审核。首轮未全部记录时禁止常规 revision export；真实恢复或当前性修复按既有授权路径处理。Surface finding 回共享精确修订机制，不恢复旧 Site revision 分支。原30/recovery-8/2/1完整输入与输出可由兼容适配器进入共享处理，不能用后来 subset Bundle 冒充原 invocation。新生成绑定当前完整输入与术语审核；历史接受按精确单元输入、候选及术语兼容证据判断，不因无关包级 SHA 变化抹掉旧 A。

Reviewer只findings/rating，不能replacement；同locale Generation/Reviewer长期session完全独立，policy仍GPT-5.6 Sol High。normalized Reviewer Bundle每Page context一份、Rows为完整Page input/target/ref/provenance；不按slot重复Document。B/C/D → 原Generation exact Page revision → validation → independent re-QC；unaffected A carry。finalize要求49 current Page、A-only、pending0、unresolved0、完整真实provenance和exact lineage。

Tour成熟present.Section/standalone eligible .go流程不重写，仍103 Page+19 Example、60/43/19 initial batches与独立QC。site milestones不改变Tour semantic authority。

## Locale plan / integrated delta-aware Surface / activation

`site-content campaign-plan` 是共享versionless locale work plan；scope分类carry/generation-required/review-required/stale-reopen/retired/ambiguous基于真实source/target/QC/Surface/compatibility evidence。exact oldTour source/target/quality/publiccontext证明后carry，新Page/structured surfaces待生成；package数量或milestone不影响classification。

`go-learning/package-language-closure/v1` 原子绑定49 Page finalization + 7 Learn data，或 current shell 的 Homepage shared Page finalization + 四份 shared structured + translation exact carry。`site-content package-closure` 使用 `--input <shared Page finalization>` 与 repeatable `--generation <structured evidence>`。旧无 Page 的 shell closure 仅历史验证。partial file/subdirectory 不能 complete。

`go-learning/integrated-locale-surface/v1`区分carried与review-required scope，绑定existing complete coverage、prospective closures、全部active routes、current unifiedglossaryReview、machine public/runtime identity、prior evidence与new/changed targets。unchanged旧Page不重新rating；carry不能伪装Reviewer重新审过。Reviewer审核new/changed语言、structured assets、cross-surface terminology、导航、homepage/translation、coverage/canonical/sitemap/publicruntime/广告integration。old TU被affected时仍必须正式revision/re-QC，Surface decision不能代替它。

```sh
go run -mod=readonly ./cmd/tour-i18n site-content surface-scope --locale <locale> --generation <package-closure.json>
go run -mod=readonly ./cmd/tour-i18n site-content surface-record --input <independent-surface-result.json>
go run -mod=readonly ./cmd/tour-i18n site-content activation-preflight --input <package-closure.json>
go run -mod=readonly ./cmd/tour-i18n site-content activation-apply --input <package-closure.json> --prior-sha256 <exact-prior>
```

independentSurface receipt immutable且绑定Markdown hash；activation需要 current完整integratedPASS，locale completion保存closure+Surface refs；以后newpackage扩展需要新的integratedgate，原exact package的历史语言judgment仍保留。每locale独立，无跨locale barrier；production/identity.json不保存language/content状态。

同一 PASS scope 中的多个 prospective closures 可分别按现有 CAS activation 依次完成，不逐 package 重做 Integrated Surface Review。currentness 只接受能够从该 receipt 的 `existing_coverage` 原 bytes 确定性重建的追加：原 completion 顺序与内容不变，每个新 completion 精确绑定该同一 PASS receipt 和 scope 内的对应 closure。原 Content Scope reference 的 SHA 必须等于 frozen baseline 的确定性编码 SHA；当前文件必须逐字节等于 baseline 加这些 completion 的正式编码。该证明仅恢复 coverage reference 的 predecessor/current 关系；完整 closure/QC、language、runtime/public context 与其余 scope 字段仍重验。consumed Surface reopen/replacement 与已冻结 Tour promotion recovery 的 historical closure reader 可通过该 lineage 读取 SHA 完全匹配的原 baseline bytes，保留原 ref/identity，不改写历史 authority，也不授权新/current reopen 或新 recovery creation。任何其他 coverage、证据或 context drift 都停止；scope 外新 package 仍须新的 integrated gate。

structured finding 使用 `site-content structured-export --task revision --finding <failed Surface receipt> --locale <locale> --output <path>`，只选择 exact finding 对应资产；旧 accepted structured evidence 与 replacement 通过该独立 receipt 形成授权 supersession，closure保留未受影响输出。未知/重复/out-of-scope finding、stale context、Markdown hash/session mismatch停止。新 locale 没有 Content Scope record 时只推导 incomplete；首次 activation以空 prior SHA atomic no-overwrite创建 sparse record，不执行第二次 locale initialization。

existing Tour locale core expansion理想新增invocations（无revision）：Unified Glossary Refresh1 Generation、Unified Review1 Review、pending Structured1 Generation、Learn/Docs Page2 Generation+2 QC Review、Integrated Surface1 Review，即Generation4 / Review4 / total8。existing current Course SEO carry；若真实derivedmetadata需要新生成，单独报告该invocation，不隐含在8内。新locale仍onecampaign，额外Tour TU和derivedstage明确单列。

## Runtime / C1 / safety

维护者已正式采用 [Shell current Homepage authority](SITE_SHELL_SUCCESSOR_AUTHORITY.md)：首次 zh-CN Site v2 release 直接使用 full frozen Homepage/shared chrome。foundation 原 pending 事实及 evidence 保持 immutable；source adoption 独立于 locale acceptance，不改 glossary/旧 completion。Homepage shared TU Bundle 是当前唯一下一份 JIT Bundle，机器校验通过后才导出 current structured Bundle。禁止用旧 home.html 或旧 completion 冒称 full Homepage complete。

保留已验收neutral opt-in `internal/site`：coverage由current Content Scope证据驱动；local covered canonical链接当前origin，未覆盖navigation直接go.dev；直接localmissing请求真实404。external URL原样；Security canonical `/doc/security/**`，legacyalias保持frozen exact/subtree fixed-target语义，只有targetlocalcovered才redirect。sitemap/canonical只含complete真实localcanonical，排除alias/data/assets/fallback。旧65Tour runtime不切换。

Advertising优先级 AdsUnsupported > GoLocal > Standard；`internal/tourpolicy` 是共享 classification authority。维护者已于 2026-10-07 冻结 AdsUnsupported exact set：sw-TZ/kk-KZ/fa-IR/am-ET，四门 publication 仍为 Standard；GoLocal 仍为 zh-CN/fr-FR/de-DE/ko-KR。homepage/translation 永远无广告，GoLocal Tour 无广告但 Learn/Docs 可按正式 Site policy 显示广告，AdsUnsupported 全站所有 current/future surfaces 无广告。原 unsupported-set Production blocker 已解除；不猜语言 tag、不联网推断、不另建第二份名单。

futureC1：source/file/route/dependency/content-unit reconcile → rebuildonecorpus → onerefresh/review → compatibility → exactnew/stalegeneration/QC → integratedSurface → activation。unchangedcarry、removedretire、newgeneration、changedPage stale、ambiguousexplicitmapping；不以wholecommit invalidation65locale。internal slots保留精确diagnostics，formalPage是review/revision boundary。

新machine evidence strict JSON、hash/selfidentity可重算、UTF-8、exact-set、traversal/symlink拒绝、immutable/no-overwrite。静态`site-content language-authority --apply`仅机械创建共享corpus与stable-index；不生成localeevidence。所有语言成果/65locale/prodidentity保持不变，本轮停止V2-D，不benchmark、不语言generation、不C1、不preview/Production、不commit/push。

正式 source authority更新后，`language-authority --prior-sha256 <exact corpus file SHA> [--apply]` 对静态 corpus做 preflight/CAS refresh；先验证 append-only Page registry，再重建 source projection，不执行 source sync，不改locale evidence。YAML item URL只是restoration coordinate，不进入 terminology context identity；machine-only code/image变动只有在projected context真正改变时才影响corpus identity。

## Post-promotion current authorization

shared TU 的正式 historical/current 分层、current re-attestation、immutable checkpoint、affected-only reopen 与 downstream steady-state 以[统一 contract](CURRENT_TRANSLATION_AUTHORIZATION.md)为准。registered package closure/runtime 默认使用同一 current authorization；新 package 增加不要求旧 package history replay。下文未建立 checkpoint 的 legacy Tour baseline reset / successor recovery 是兼容 migration 路径，不反向成为 future locale 的常规前置步骤。

Course SEO historical whole-file ref 不能借 TU successor carry。历史 archive/recovery WIP 保留、不扩展、不 apply，也不再是继续 Site v2 的前置条件。existing Tour 的合法 historical completion root + exact-current schema-v4 full Surface A + 独立 current Unified Glossary Review / finalized A-only TU / canonical authorization / strict Course SEO，组成只读 current checkpoint；不新增 closure/schema，不修改历史 evidence，不恢复旧 whole-file bytes。

Promotion 后历史 Reviewer A 不变；current target 必须另有 [accepted-target successor proof](SITE_V2_ARCHITECTURE.md#accepted-translationunit-target-successor-authority)。未来正式 `retranslation promote --apply` 必须指定 finalized Snapshot，自动保存 native receipt；旧实现缺 receipt 的历史只能由维护者显式执行 `retranslation recover-promotion --locale <locale> --snapshot-id <snapshot-id>` preflight，再明确 `--apply` 保存 historical recovery，不自动补写、不重跑 promotion。

`quality-check authorization --locale <locale> --snapshot-id <snapshot-id>` 分别输出 immutable Reviewer A 数量与 current canonical authorization；缺 receipt/recovery 时返回非零，不能把 pending current authorization 解读成 Reviewer 推翻旧 A。合法 successor 存在时 current QC/finalization 继续验证原 A-only/carry-forward，全套旧 evidence 不改写。

Native receipt 仅在 canonical/status 完整安装及 exact 复验后发布；recorded status bytes 是当时投影，不要求 mutable status 当前 SHA 永久不变。未收口 `.promotion-staging-*` 保留 backups 并阻止 current authorization、campaign-plan 与下一写操作；不得把 staging 中的 JSON 当作已成功 receipt，也不得盲目重放。

TU successor event 验证仍严格绑定 TU-critical historical evidence，但 recorded non-TU mutable context 不作为永久 current-SHA oracle；完整 proof_inputs 与 immutable historical membership 不改写，TU receipt 不授权 derived consumer。`campaign-plan` 只有完整 current checkpoint 成立才越过历史 mutable whole-file refs；否则维持原 fail-closed 路径。新的完整 Surface A 是一次 legacy baseline reset，后续 unchanged Tour carry、新 package/new Page 只审核真实 new/changed/affected scope，继续 package closure / Integrated Surface，不要求每次 full Tour 重审。Recovery 默认 dry-run、deterministic/content-addressed/no-overwrite，apply 仍是维护者 Local terminal 操作。
