# ChatGPT 正式语言生成执行规范

全项目执行共同遵守[共享翻译单元生命周期与五角色协作](SHARED_TRANSLATION_UNIT_LIFECYCLE.md)：所有内容表面复用同一生命周期；页面差异限于适配器；传输安全与逐单元机器校验分层；先恢复、先复用，中文说明，交接只给一个执行者、动作和停止条件。本文中 Tour 的 present / Example 细节属于 Tour 适配边界，不另建 Learn/Docs 状态机。Learn/Docs 两批生成和机器校验全部完成后才初审，两批初审全部完成后集中修订。角色与工具分工不替代任何正式 machine authority 或语言质量 gate。

本文定义某个 locale 在开始正式 generation 前选定 `provider=chatgpt` 后，普通 ChatGPT **GPT-5.6 Sol + High** 配合 Remote Desktop Commander 执行正式语言生成时的仓库边界。它与 [Codex 正式语言生成执行规范](CODEX_TRANSLATION.md) 并列；不新增 Translation Engine，也不改变任何 validation、Quality Check、Locale Surface Review 或 Production gate。

## 单 locale 固定会话角色

所有 Generation/Reviewer/Local terminal 阶段交接统一遵守 [正式阶段交接合同](WORKFLOW_HANDOFF.md)：先完成合法的闭环内短机械操作，再提供真实 current attachment 或完整恢复命令；不得编造路径、hash 或 CURRENT。

一个 locale 默认维护一个长期 **Generation session**、一个与之独立的长期 **Reviewer session**，再由维护者 **Local terminal** 执行闭环外的成组 deterministic lifecycle；闭环内短机械步骤按下文由具备仓库终端能力的 AI execution environment 自动完成。这是协作职责规则，不是机器身份系统；不得为此新增 session 字段、receipt、schema、CLI flag 或 machine gate。

### Generation session

Generation session 负责所有产生或修订该 locale 语言内容的模型工作：

- locale glossary 的语言判断与制定；
- 公共 UI catalog、article metadata 与其他 locale-level 文案的生成或修改；
- TranslationUnit initial translation、revision，以及确实需要新译文的 `restore_failed` / `validation_failed` retry；
- schema v2 Course SEO localization，以及 Surface Review finding 所需的 refresh / revise description；
- Glossary Review、TranslationUnit Quality Check 或 Locale Surface Review finding 回流后的 replacement generation。

同一个 Generation session 可以按 `glossary → Glossary Review PASS → UI / metadata → TranslationUnit initial / revision → Course SEO localization → 后续 replacement generation` 长期连续工作，只要它始终承担 generation。它可以读取完整 source、target、glossary 与 reviewer finding；Course SEO generation 可以读取当前完整 Page source 与 ready target。读取这些材料不会破坏 generation 独立性，真正禁止的是同一 conversation/session 同时承担 generation 与 formal review。

Generation session 不得执行正式 TranslationUnit Quality Check、revision 后正式 re-QC、Locale Surface Review，或批准自己生成的输出。

Generation session 制定完整 glossary 后必须停在 Glossary Review 边界；只有 generation-independent Reviewer PASS 且当前 AI execution environment 记录并检查 current gate 后，才正式生成 UI / article metadata 并进入 TranslationUnit generation。若 Reviewer 返回 failed finding，Generation session 负责修订 glossary，并在继续下游 generation 前交回同一独立 Reviewer session 完整复审。

### Reviewer session

Reviewer session 负责该 locale 的正式语言审核：

- Glossary Review；
- TranslationUnit Quality Check；
- revision 后 re-QC；
- Locale Surface Review。

同一个 Reviewer session 可以先承担 Glossary Review，再承担 TranslationUnit Quality Check，之后继续承担同一 locale 的 Locale Surface Review。这三个 gate 的范围和 evidence 保持独立，但仓库不要求它们使用不同 reviewer conversation/session。前提是该 Reviewer session 从未参与该 locale 的 glossary、UI catalog、article metadata 或其他 locale-level language generation，从未参与 TranslationUnit initial / revision / retry generation，也从未参与 schema v2 Course SEO localization / revision generation。

Reviewer 发现问题时必须遵循：

```text
reviewer finding
→ Generation session 产生 replacement
→ AI execution environment 执行闭环内 deterministic lifecycle
→ Reviewer session re-review
```

Reviewer session 不得直接修改 candidate、生成 replacement translation 或 Course SEO replacement description 后再批准自己的结果，也不得因为自己审核过上一轮而自动批准 revision。只要它没有参与 replacement generation，就可以继续审核 Generation session 修订后的新输出。Validation passed、旧 A、Surface Review 结论或模型历史表现都不能替代当前正式审核。

TranslationUnit Quality Check 与 revision re-QC 的单次 Reviewer model invocation / response 最多审核 60 TranslationUnits；Page / Example 分开。60 是实际审核质量边界，不得通过在同一次 response 内串联多个 `<=60` working set 绕过；下一组需要新的用户请求和新的 model invocation。每组必须逐 TranslationUnit 审核，不得抽样。首次 122-Unit locale 的 full QC 推荐使用 Page stable index `1-60`、Page stable index `61-103`、Example stable index `104-122` 三组；revision re-QC 按实际 pending scope 分组，每组最多仍为 60。

### RDC 调用预算与回退

Generation 与独立 Reviewer 均遵守[Bundle 冻结输入与工具回退](WORKFLOW_HANDOFF.md#bundle-冻结输入与工具回退)：完成 current-check 并上传的完整 Bundle 直接从附件或本地解压内容读取，semantic work 默认 RDC calls = 0。不得为确认 Bundle 内 source/candidate/glossary/finding/manifest/authority 再次 rg/find/cat 仓库，也不得把人工扫描当作 current-check。

semantic output 完成后，landing/import/process/validation/scope/hash 等短确定性操作尽量合并为一个 shell invocation，保持原有依赖顺序和 fail-closed gate，一次报告终态；目标是 1 个合并执行 call，工具必须异步时再允许 1 次最终结果读取。不得为每个 read/hash/check/import/process 单独开 RDC call，不连续 `list_sessions` / `read_process_output` 轮询。预计超过约 3 秒且可由维护者无判断执行的长任务，或需要多次轮询的任务，优先交给 Maintainer Local terminal 一条完整命令并回传终态。unexpected failure diagnosis 可以超出调用目标，但必须由真实 failure evidence 触发，并优先合并诊断命令；已有可信 outputs/result/staging 不重做。

RDC 不可用或额度耗尽时，继续用上传 Bundle 完成语言工作，按共享交接合同转由 Local terminal 执行机械步骤、本地 Codex CLI 承担仓库工程；无终端能力的模型不得伪报 landing 或验证成功。此回退不改变会话隔离及任何 gate。sequential QC/re-QC 仍[只导出当前下一组](WORKFLOW_HANDOFF.md#qc--re-qc-reviewer-bundle-按需即时导出jit)，previous record 成功后才导下一组，禁止预导未来 Reviewer ZIP。

### 闭环机械操作与 Local terminal

新增 locale 的首次大批量 TranslationUnit Generation 仍由维护者 Local terminal 导出 current provider-neutral Generation Bundle ZIP 并上传给 Generation session。ChatGPT 不通过 Remote Desktop Commander 逐文件读取正式输入，也不重新扫描仓库替代附件。ChatGPT 将完整 TranslationUnit 成组保存到按 locale + batch 隔离的本机隐藏 staging；每个文件先写入临时文件，完整写入后再 rename 为该 TranslationUnit 的正式 staging 文件，避免把不完整文件暴露为完成结果。完成 exact-set 检查后默认执行目录 import；不制作或下载 outputs ZIP。随后执行正式 process / automatic validation，每批通过后停下等待维护者明确“继续”。跨环境传输、RDC 不可用或目录导入不适用时保留 Result ZIP 回退。

首次 Generation ZIP handoff 后，具备仓库与终端访问能力时，ChatGPT + Remote Desktop Commander 默认从本地隐藏 staging 直接 import 首次 bulk 输出并执行 process / automatic validation；小批 revision / retry 也复用目录 import，只有兼容回退需要时才处理 outputs ZIP / Result ZIP。其余闭环内短 deterministic 操作包括 Snapshot / scope / reviewer-bundle、审核结果 current-check / record / finalize、locale-level replacement 落盘、Surface Reviewer bundle / record-a，以及 Course SEO description 落盘和正式 assemble / refresh / revise。机械执行不得让 Generation session 承担 Reviewer 的语言判断，也不得让 Reviewer 生成 replacement；每个 current-check、exact-set、A-only、schema 与 provenance gate 都照常执行。终端能力不可用、需要新的附件 handoff 或出现真实 failure / mutation-unknown 时才停下交回维护者。

维护者 Local terminal 负责闭环外或闭环收口后的成组步骤：locale init、首次 bulk export / Generation ZIP handoff、promotion、build、preview、browser verifier、publish、shared assets、Production、deploy、verifier、checksum / curl、search closeout，以及按正式顺序需要的最终 Git commit / push。ChatGPT 给维护者提供可直接粘贴的终端命令时，不得在当前交互 shell 顶层启用 `set -e` / `set -u` / `set -o pipefail` 或组合形式；需要 fail-fast 时必须用独立 subshell 或独立脚本进程，避免失败退出或改变维护者当前 shell。

对 `preview` + browser verifier、`publish`、`shared-assets-production.sh`、`first-production.sh`、`indexnow-closeout.sh` 等可能持续数十秒到数分钟的成组确定性命令，普通 ChatGPT + Remote Desktop Commander 只给出一条完整可粘贴命令，由维护者在本地终端执行并把终态输出回传；不要为了等待完成而反复调用远程 process-output 轮询。脚本内部的 machine gate、receipt、bounded retry 和 HUMAN gate 均保持不变。

Locale Surface Review 的 Reviewer 输入默认由当前 AI execution environment 使用 `surface-review reviewer-bundle` 生成并完成 current-check；产品界面需要人工附件上传时，只把实际 ZIP handoff 留给维护者。只要该 bundle 来自未变化的正式输入且 `manifest.json` hash 校验成立，Reviewer 对附件内 `surface-review.json` 与 `authority/` 的完整读取即满足本轮正式输入读取，不应再通过 Remote Desktop Commander 重复扫描这些仓库文件。任何正式输入或 bundle 内 authority 发生变化，都必须重新导出 bundle；附件模式不允许抽样、跳过 Course SEO full-context coverage，亦不改变独立 Reviewer 与 finding → Generation 回流边界。

canonical English source-description extraction / review 是所有 locale 共享的 authority，不属于单个 locale 固定的 Generation / Reviewer 配对。只有其 authority 确实 stale 时才按 [课程页正式 SEO Metadata 规范](COURSE_SEO_METADATA.md) 执行，不因新增每个 locale 重复，也不默认交给该 locale 的 Reviewer session。

本规范只适用于已经选定 ChatGPT 的 locale Generation role。provider-neutral 的选择、持续使用和例外切换规则由 [多语言翻译流程](TRANSLATION_WORKFLOW.md) 与 [新增 Locale 执行手册](NEW_LOCALE_RUNBOOK.md) 规定；Remote Desktop Commander 的闭环自动化边界不扩展到维护者的 promotion / build / Production / Git 成组操作，也不接管 Codex 的 repository-level code/docs/config、tooling 与复杂诊断职责。无论 Generation provider 为 ChatGPT 还是 Codex，generation 与 formal review 的会话隔离规则不变，Reviewer 继续使用独立 ChatGPT GPT-5.6 Sol + High session。

## TranslationUnit 正式输入与 export

ChatGPT TranslationUnit 执行仍以 [翻译任务规范](TRANSLATION_TASK_SPEC.md) 为 provider-independent contract。每个 batch 的以下三部分是不可拆分的正式输入：

1. `manifest.json`；
2. manifest 列出的全部 `inputs/*`；
3. `locales/<locale>/glossary.yaml`。

开始写任何 raw response 前，生成 session 必须完整读取三部分；不得用聊天上下文、上一批输入或 glossary 摘要替代仓库当前字节。

ChatGPT batch 必须显式导出为：

```sh
go run -mod=readonly ./cmd/tour-i18n retranslation export \
  --locale <locale> \
  --generator chatgpt \
  [--unit-kind page|example] [--limit <count>] [--id <unit-id> ...]
```

未提供 `--batch-id` 时，`--generator chatgpt` 选择 `chatgpt-<locale>-NNN`；Codex 是兼容默认并使用 `codex-<locale>-NNN`。两种 prefix 共享同一 numeric namespace，latest export、Candidate Snapshot 与 promotion 都按 numeric suffix 判断，不按 prefix 字典序判断。显式 `--batch-id` 保持既有兼容语义；generator 不写入 manifest，也不构成可由机器证明的模型 provenance。

新增 locale 的首次 Page batch 仍使用 60-Page 基线，Examples 独立。初次自动 Page / Example、显式 `--id`、正常 Quality Check B/C/D revision 与 Surface reopen 精确 revision export 均使用默认且硬性上限 60，Page / Example 永不混合；当前正式课程仍只有 19 个 eligible Example，不为凑满批次扩大 scope。retry 范围不变。

若 candidate 生成后 glossary 已经合法修改并重新取得完整 current Glossary Review PASS，只有正式 protector 在当前 glossary 下重建出的 protected input 与 latest processed batch saved input 字节不同的 Unit 才进入 glossary-stale recovery：

```sh
go run -mod=readonly ./cmd/tour-i18n retranslation export \
  --locale <locale> --generator chatgpt \
  --allow-reexport --glossary-stale \
  --id <unit-id> [--id <unit-id> ...]
```

该模式不是 QC revision、Surface reopen、retry 或 revalidation，不使用 stale `--previous-snapshot-id`，也不允许 unaffected Unit。其 Generation Bundle task kind 为 `translation-unit-glossary-stale-recovery`；ChatGPT 仍按当前完整 glossary 与新 protected input 生成 replacement，并以 `provider=chatgpt`、`model=gpt-5.6-sol-high` 走普通目录 import/process。input identity 未变化的 candidate 保持不动。随后必须建立 full Snapshot，并因 glossary identity 变化执行完整 QC；旧 A 不 carry-forward。

initial Page / Example bulk export 后由 Local terminal 生成 provider-neutral Generation ZIP 并 handoff；ChatGPT 完整读取一个附件即可取得 manifest、全部 inputs、完整 glossary 与当前 authority，无需再通过 Remote Desktop Commander 逐文件读取。译文写入 `/tmp/.go-tour-i18n-generation/<locale>/<batch-id>/` 隔离目录；首次 Page / Example、revision 与 retry 都可使用同一目录 import：

```sh
go run -mod=readonly ./cmd/tour-i18n generation-bundle export \
  --locale <locale> --batch-id <batch-id> \
  --output /tmp/<locale>-<batch-id>-generation.zip
```

首次 122 Unit 的默认调度固定为 60 Page、43 Page、19 Example 三个 initial batch；每个 batch 使用一次 model invocation，正式落地并取得 automatic validation evidence 后停止，等待维护者明确“继续”。不得在一次 response 串联多个 initial batch。完整顺序与合法恢复边界见[新增 Locale 执行手册](NEW_LOCALE_RUNBOOK.md#新增-locale-默认调度路径效率优先)。

ChatGPT 在隔离 staging 中成组保存完整 TranslationUnit，并检查 expected filename exact set、protected token、glossary、明显未翻译文本、无解释/fence 与 single-LF。具备本地文件访问能力时直接运行：

```sh
go run -mod=readonly ./cmd/tour-i18n generation-bundle import \
  --bundle /tmp/<locale>-<batch-id>-generation.zip \
  --input-dir /tmp/.go-tour-i18n-generation/<locale>/<batch-id> \
  --provider chatgpt --model gpt-5.6-sol-high
```

该命令直接检查目录，不创建 Result ZIP。确需跨环境传输时，outputs ZIP 仍只是原始输出传输包，先由 `result-pack` 生成正式 `kind=go-tour-i18n/generation-result-bundle` Result ZIP，再使用 `import --result`；历史 Result ZIP 也继续兼容。

`generation-bundle import` 对目录与 Result ZIP 共用 current canonical bundle、全部 input identity、locale/batch/task/attempt、provider/model、exact-set、路径、UTF-8/no-BOM/single-LF、protected restore、glossary 与 machine candidate 检查，并以同一已验证字节安装。导入会将既有 `GenerationResultBundleManifest` 持久保存为 provenance 记录，不新增 schema；记录 provider、model、Generation Bundle SHA-256、input identity、attempt 与输出 hashes。import 不等于 `retranslation process` / `retry` 写出的 automatic validation evidence，更不等于 Quality Check；每批通过 automatic validation 后仍停下等待维护者明确“继续”。

Reviewer ZIP 继续由维护者上传给独立 Reviewer。只有确需兼容 outputs ZIP / Result ZIP 或 Reviewer ZIP 时，才涉及当前产品所需的附件上传/下载；本流程没有无需用户操作即可跨 ChatGPT / Ubuntu 或跨 session 双向传送附件的通道。

恢复执行前先核对 `raw-responses/` 或 retry attempt、generation import provenance、`result.json`、`validation/`、Snapshot 与 QC evidence。若正式输出已经 import，直接从缺失的 process / retry 或后续 evidence 继续；若 automatic validation evidence 已 current，则不得覆盖输出、重复 import 或重放 validation。若产品消息流/模型 invocation 在 import 前中断且正式输出尚不存在，不得立即让 ChatGPT 重做整个 batch：先对仍 CURRENT 的 Generation Bundle 运行 `generation-bundle recover`，把旧 hidden staging、临时单文件和可识别的 interrupted tar/tar.gz artifact 作为一个或多个 `--source`，只把通过 filename、UTF-8/EOF、protected restore、glossary 与 machine candidate 检查的完整 Unit 写入新的 recovery staging；archive 尾部损坏不抹掉此前独立验证通过的完整成员。随后只生成命令列出的 `missing` Unit，补齐 exact set 后再正常 import。CLI 的 stale、conflicting valid candidate、exact-set 与 no-overwrite failure 都是保护信号，不是要求清空可信成果后重来。

### Generation finding closure 执行规范

`translation-unit-revision` 及其 machine retry 的完整 CURRENT Bundle 必须同时包含三层表示：protected source/input、`formal/candidates/<input basename>` 中的精确 reviewed restored candidate、`formal/protected-candidates/<input basename>` 中的 passed predecessor protected raw response，以及 Snapshot/validation、finding authorization、glossary 和 authority，详见[Generation Bundle contract](TRANSLATION_TASK_SPEC.md#deterministic-generation-bundle-transport)。实际编辑从 protected predecessor baseline 开始；finding closure 对照 restored candidate。输出必须是保留全部 tokens exactly and uniquely 的 protected raw response，不得直接输出 restored candidate或自行重建 token mapping。不得从聊天记忆恢复、通过 RDC/repo scan 另取 latest candidate，或从 English input 整页重译替代 exact revision。缺项时正式 FAILED 且不生成 outputs；修复合同后，无正式输出时重导同 batch，有失败 evidence 时仅走下一连续 attempt 的单 Unit retry，保留旧 failure evidence。`task_kind=translation-unit-retry` 不丢失原 revision semantic inputs 或 finding closure 责任。

Quality Check、re-QC 或 Locale Surface Review finding 进入 TranslationUnit revision 后，Generation 必须按[精确修订任务语义](TRANSLATION_TASK_SPEC.md#精确修订任务语义)逐 Unit、逐 finding 完成 closure；同一 finding 中独立指出的多个问题也必须分别处置。不得只修最严重或最显眼的一项就视为该 Unit 完成。

1. 完整对照正式输入中的 source、current candidate、previous Reviewer finding、glossary 与 protected/structure requirements，辨明 finding 的每个独立问题。实际 candidate defect 必须修复；source 原貌、protected content、合法结构移动或 validator / Reviewer 误判必须区分，不能一律当作译文缺陷。
2. 修复必须以 finding 为锚点。修复后重新检查所在句子、相邻紧密语句、段落，必要时检查同一小节中直接受影响的局部；该局部中与 finding 同类型、明显、用户可见且属于 editable candidate prose 的缺陷，必须在同一次 revision 一并收口。不得扩大到无关段落或整页风格重写。
3. 典型局部缺陷包括：同一局部另一处不必要的 `e.g` / `NOTE` 双语残留、中文正文中的同类异常 `--`、与正文分离的孤立句末标点、finding 或其修复直接造成的异常空行/机械断行，以及同一表达中 API/code/link identity 周边的中文自然语言边界问题。涉及安全分类列表、披露流程等技术语义时，必须重新核对 source 的分类、条件与流程关系，不得只做表面措辞修补或凭 finding 增补语义。
4. 上述形式不是一律错误。来自 canonical source、protected binding、code/link/API identity、required markup 或合法 Page structure 的内容，不得为了自然化或“清零 finding”擅自改动；合法软换行与允许的完整结构移动也不得机械消除。对保持项必须明确其 source/protected/structure 依据；疑似 validator 误判按下节诊断规则处理，不绕过现有 gate，也不改写 Reviewer finding/evidence。
5. 每个 revised Unit 提交前必须完成 **finding closure check**（任务完成性检查）：重新对照 source、revised candidate、previous Reviewer finding 与 protected/structure requirements，确认每个独立问题已修复，或有明确依据保持，并确认上述 affected-locality completeness。若仍有未处置问题，不能把该 Unit 视为 revision 已完成。检查使用当前完整 Bundle 内的正式材料，遵守 Bundle-local semantic work、语言 semantic RDC calls 默认 0 的边界。
6. finding closure check 不是正式 Quality Check，也不是 self-review：Generation 不得给自己 A/B/C/D、决定通过、替代 Independent Reviewer 或伪造 reviewer evidence。修订仍输出完整 Unit，处置说明不得混入 raw response；后续 machine validation、独立 re-QC / Surface re-review 与 A-only finalization 全部照常执行，不新增 closure schema、receipt、状态或机器 gate。

Transport Bundle 大小与 semantic completion contract 分开：一个正式 Revision Generation Bundle 仍可包含现有 export 上限与 Page / Example 分离约束内的当前完整 revision scope，不因 closure 规则拆成每 3–5 Page 一个 ZIP，也不新增 Generation invocation size 上限。正式 B/C/D / Surface reopen revision 可跨 initial group；Learn/Docs 固定 batch 调度仅约束 initial Generation / initial QC，revision re-QC 使用[共享 pending 调度](SHARED_TRANSLATION_UNIT_LIFECYCLE.md#固定调度与独立审核)。未来若研究 invocation size，须另有 benchmark/evidence；finding closure 不改变 Reviewer invocation 上限或 Reviewer Bundle JIT。

这些例子不成为 hard validator 新规则：部分形式可能来自 source/protected content，当前 evidence 只支持加强 revision closure contract，尚不足以建立可安全泛化、无误报的 machine rule。未来若多 locale 重复出现，可另行依据 evidence 评估 advisory lint / precise validator；现有 validator 与 gate 保持不变。

### Validator 冲突的主动诊断

长期 ChatGPT Generation session 在目标语言自然句法与 validator 冲突、或怀疑 validator 漏检时，必须按 [翻译任务规范](TRANSLATION_TASK_SPEC.md#generation-执行者主动诊断-validator) 主动完成证据诊断，而不是把所有报错归为译文错误或为过 gate 机械改写自然译文。诊断至少核对完整 source/candidate、全部 protected token、restore/validation evidence，必要时核对真实 Go Present 解析/渲染或 Go 源码语义，并明确区分翻译缺陷、非法结构/代码变化、受保护内容破坏、validator 误报/漏报及 session 自行增加的过度预检。

普通 Page 允许完整 inline-code pair 与完整链接连同自然语言按目标语言语序整体移动，同时保持 link label-target 绑定和全部结构关系；不得对 Page 额外施加 Example 才有的全局固定 token 顺序。Example 仍严格保持 token 顺序、完整 Go 文件和非注释机器语义，只翻译正式允许的 teaching comment 自然语言。

ChatGPT Generation session 可以保存完整复现、positive/negative fixtures 与确定性最小修正方案，优先提出通用修正；只有充分证据证明通用方案不适用时才提出窄化的 locale-specific 规则。它不得自行修改生产 validator 或共享校验规则，必须停在维护者批准边界并交给获授权的仓库级 Codex 任务。不得用不自然空格、删句、伪造 retry、重译已审核通过成果或降低任何语言 gate 绕过疑似误报。只有正式批准并实施规则修复、restore 已成功且原 candidate 已证实有效时，才使用正式 `retranslation revalidate`；真正的语言质量问题继续走 revision 与独立 re-QC。

## Remote Desktop Commander 安全写入

首次翻译或 revision 不得逐个文件直接建立正式 `raw-responses/`。在同一 batch filesystem 内执行以下顺序：

1. 确认正式 `raw-responses/` 尚不存在，在 batch 内创建隐藏 staging directory，例如 `.raw-responses.staging/`。
2. 将整个 batch 的每个 Unit 完整输出写入 staging；Page 使用对应 `.article`，Example 使用对应 `.txt`。
3. 对照 manifest 核对 expected filename exact set 与 count，并逐文件检查 protected token、glossary、明显未翻译自然语言、无 Markdown/code fence/解释，以及恰好一个结尾 LF。
4. 只有全部检查通过后，才在同一 batch 内将整个 staging directory rename/move 为 `raw-responses/`。

任何检查失败或 Remote Desktop Commander 中断时，隐藏 staging 不是正式 raw response，必须保留为未完成工作或安全清理；不得留下部分 `raw-responses/`。正式目录已存在时不得覆盖或合并，必须先查明当前 batch 状态。

Retry 使用同一原子提交思想：先将完整内容写入目标 Unit retry 目录内的隐藏 staging file，核对它满足当前连续 attempt 编号、文件名、protected token、glossary 和 single-LF contract，再 rename 为正式 `attempt-NNN.article` 或 `attempt-NNN.txt`。不得覆盖既有 attempt、跳号或伪造 provenance。

手工 Remote Desktop Commander 直接安装到正式 `raw-responses/` / retry 路径，只作为目录与 Result ZIP importer 都不可用时的兼容恢复路径；不得与同一 attempt 的 `generation-bundle import` 混用或覆盖既有文件。标准目录 import 使用独立隐藏 staging 作为输入，再由 CLI 安装验证过的字节。无论哪种 transport，`retranslation process` / `retranslation retry` 继续是 candidate、validation evidence 与 attempt lifecycle 的正式 fail-closed authority。

## 非 TranslationUnit 语言资产

这些资产按以下输入边界生成或修改：

- 首次制定 locale glossary：先遵循 [术语治理政策](TRANSLATION_TERMINOLOGY.md) 与 [术语制定指南](TERMINOLOGY_GUIDE.md)，并读取制定术语所需的正式 English/source context；尚未建立完成的完整 locale glossary 不是其自身的前置输入。
- 修改已有 glossary：必须读取完整当前 glossary 与相关正式 source/context。
- 生成或修改 UI catalog、article metadata 等其他 locale-level 语言资产：必须读取对应完整 source/context 和已经建立的完整 locale glossary。

首次 glossary 制定或任何使当前 Glossary Review coverage stale 的修改，都必须按 [Glossary Review 规范](GLOSSARY_REVIEW.md) 由 Reviewer session 完整审核。UI / article metadata 的正式 generation 排在 PASS 之后；Glossary Review 不因这些资产已经存在而自动批准。

所有资产仍须保持现有 key、kind、placeholder、markup、schema 和技术 identity。不得给 `glossary.yaml`、`internal/tour/ui/<locale>.json` 或 `article-metadata.json` 增加 provider/model/generation 字段。Glossary 继续是该 locale 的正式术语 authority，这些资产也继续由现有 validator 与 Locale Surface Review 审核实际内容。

这些 generation 输入优先一次性导出：

```sh
go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-export \
  --locale <locale> --task glossary \
  --output /tmp/<locale>-glossary-generation.zip

go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-export \
  --locale <locale> --task locale-assets \
  --output /tmp/<locale>-locale-assets-generation.zip

go run -mod=readonly ./cmd/tour-i18n generation-bundle locale-export \
  --locale <locale> --task surface-replacement --review-id <review-id> \
  --output /tmp/<locale>-surface-replacement-<review-id>.zip
```

`glossary` 包含完整 locale identity、English/source corpus 与 terminology authority；`locale-assets` 在 current Glossary Review 后包含完整 UI/article source、当前 target 与 glossary；`surface-replacement` 还绑定指定 reviewer evidence 和 current full Surface Review package。开始或记录结果前用 `generation-bundle locale-check --bundle <zip>` 确认 current。此 contract 只运输生成上下文和预期 deliverable，不直接覆盖正式 locale 资产；闭环内由当前 AI execution environment 按现有 validator/lifecycle 正式落盘，Reviewer finding 仍须返回 Generation session 后再独立复审。

首次 schema v2 Course SEO localization bundle 默认由当前 AI execution environment 从正式 working tree 生成并检查；产品界面需要人工附件上传时，只把实际 ZIP handoff 留给维护者：

```sh
go run -mod=readonly ./cmd/tour-i18n course-metadata localization-bundle \
  --locale <locale> \
  --output /tmp/<locale>-course-seo-localization-generation.zip
go run -mod=readonly ./cmd/tour-i18n course-metadata localization-bundle-check \
  --locale <locale> \
  --bundle /tmp/<locale>-course-seo-localization-generation.zip
```

ZIP 的 `course-seo-localization.json` 对 Catalog 全部当前 Page 逐页序列化 canonical English description、完整 English Page source、完整最终 ready target、source/source-description/target identity，并绑定 current canonical source-review authority、完整 glossary 与 `locale.json` identity；`formal/source-descriptions.json` 同时保留 canonical asset 的原始正式字节，`formal/` 还包含 glossary 与 locale identity；`authority/` 封装 ChatGPT/Codex generation、Course SEO、workflow 与 `AGENTS.md`。`manifest.json` 为全部文件提供 SHA-256。只要 bundle 来自未变化的正式 working tree 且 manifest/hash 完整，Generation session 直接完整读取附件，不再通过 Remote Desktop Commander 分批读取同一 103-Page context。ZIP 只优化传输，不新增 Course SEO schema、receipt 或 stale identity，也不允许跳过任一 Page；Codex 使用完全相同的 bundle contract。

schema v2 refresh/revise 使用独立 maintenance bundle，仍由既有 CLI 写正式 asset：

```sh
go run -mod=readonly ./cmd/tour-i18n course-metadata generation-bundle \
  --locale <locale> --task refresh \
  --output /tmp/<locale>-course-seo-refresh.zip

go run -mod=readonly ./cmd/tour-i18n course-metadata generation-bundle \
  --locale <locale> --task revise \
  --page-id <page-id> [--page-id <page-id> ...] \
  --finding data/locale-surface-reviews/<locale>/<review-id>.md \
  --output /tmp/<locale>-course-seo-revise-<review-id>.zip
```

refresh 自动选择 exact stale subset；revise 要求 current schema-v2 base、显式 Page subset 与 repository 内 reviewer finding。下载的 strict `page_id`/`description` JSON 仍交给 `course-metadata refresh` / `revise`，真实 provenance 由调用者明确记录。

schema v2 Course SEO localization 允许并推荐为每个当前 Page 提供 canonical English description、完整 English source、完整最终 ready canonical locale target、完整 locale glossary、locale identity 与 `course-seo-localization-v2` constraints。canonical description 是唯一 semantic-scope authority；source/target 只用于技术语义核对、正文术语一致性、自然表达和实际内容对齐，不授权重新摘要、增删语义或重选重点。同一 session/batch 可处理多个 Page，但每页必须只用自己的 canonical description 决定 semantic scope，不得跨页补充、混合或推断语义。普通 ChatGPT 的真实 provenance 固定记录为：

```text
provider=chatgpt
model=gpt-5.6-sol-high
```

生成 session 只产出 `page_id → localized description` 输入，不得直接手写正式 `course-metadata.json`。具备仓库终端能力的当前 AI execution environment 默认把 strict descriptions JSON 正式落盘，并立即运行现有 `course-metadata assemble` / `refresh` / `revise` CLI 机械生成资产、记录真实 provenance 并通过现有 gate。canonical English source-description 使用当前共享 authority；普通 locale 生成不重新生成它，也不改变其 review gate。

Course SEO revise 对明确 subset 可额外向 generation session 提供 current localized description 与独立 reviewer finding，两者只用于定位和修复语言质量问题，不能取代 canonical description 的 semantic scope，也不得把 finding 当作增加新语义的依据。生成 replacement 后由当前 AI execution environment 自动运行 `course-metadata revise`，机械更新正式资产与真实 provenance，再交由独立 Locale Surface Review session 复审。
