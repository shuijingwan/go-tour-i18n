# 正式 Page replacement lineage

本合同复用[共享生命周期](SHARED_TRANSLATION_UNIT_LIFECYCLE.md)和既有 Surface reopen、revision、Generation Bundle、process、Snapshot、QC 与 A-only finalization。Page ID 算法保持不变；protector representation 真实变化仍产生新 ID，旧 Bundle 自然 stale。

## 必要性与最小扩展

既有 exact-source mapping 只能证明物理 source，不能证明旧 protected ID 与当前 ID 的关系；旧 reopen 和 batch 又只能绑定 predecessor Snapshot 的原 ID。仅忽略 ID mismatch、按 path 选择 latest candidate 或改写旧 batch 都会失去授权证据。因此在现有 schema-v1 reopen 上增加可选 `replacement_context` 和逐 Unit `replacement`，作为新的 immutable successor reopen；不新增独立 receipt/schema 或状态机。旧 single-finding、aggregate 和无 replacement revision 原样读取。

`replacement_context` 绑定原 reopen 的 repository path/SHA 和显式 frozen Page representations 的 path/SHA。冻结文件为 `HistoricalPageRepresentations` JSON，包含 `package`、`package_sha256`、完整有序 `documents`（含原 formal Unit、internal slots、protected raw/role/pair）。必须提供真实保存的旧表示；不得从 candidate、path、stable index 或最新文件猜测旧 token mapping。缺少完整旧表示时 fail closed。该输入进入 successor 和 Bundle identity，文件改动会使 current-check 失败。

`ReconcileHistoricalPages` 使用既有 `ReconcileDocuments` 的同一确定性 matching 实现。历史表示通过 frozen slots 重组、protected ID、source hash 和源坐标验证，不用当前 protector 要求它重新变为 current 表示。当前表示仍通过当前 parser 重建。双方必须为同 package authority、同 kind、同 physical path/source bytes/SHA、同 route、同 registry index、同 dependency identity，各一个 formal Page；完整 membership 和顺序一致。重复、歧义、移动、源字节变化或伪造 slots 均拒绝。旧 ID 与 current ID 不同时必须有真实 protected-input drift 和唯一 reconciliation replacement；不授予旧译文或 A 的自动继承。

## successor authorization

维护者之后明确执行真实恢复时，使用既有 `quality-check surface-reopen`，另外指定 `--previous-reopen-id` 和 repository-relative `--historical-documents`。必须使用新的 reopen ID，并显式给出 current UnitIDs、原 Snapshot、原 Surface review 和完全相同的 selected findings。此文档不代表已经创建任何真实 successor。

reader 先使用显式 historical inventory 验证原 finalized Snapshot、原 reopen、独立 Surface receipt/session/context、candidate、validation 和原 UnitID，再重算 reconciliation。历史 artifact 验证与 current artifact 验证分开；`ValidateSurfaceCandidateArtifact` 仍拒绝旧 ID 冒充 current。每个 replacement 绑定 old/current ID、package authority、path/source SHA、registry index/route、old/current input SHA 和 reconciliation SHA。旧 input 还须匹配原 Snapshot 所选 batch 的正式 input hash。混合 unchanged/replacement scope 沿用同 predecessor、同 Page kind、最多60、exact selected findings 和一个集中 revision batch。新授权不覆盖旧 evidence；已有新正式结果时不能再次用旧授权建立 batch。

## revision 与 QC

新 batch 只记录 current ID，immutable successor reopen 显式解析其 historical predecessor ID。Generation Bundle 冻结 current source/input、old Snapshot/candidate/validation、原 Surface authority、原 reopen、successor reopen 和 frozen representations。对 replacement，`formal/historical-protected-candidates` 保存原 passed raw response；`formal/protected-candidates` 是通过源坐标确定性转换的当前 token baseline。转换仅允许把旧 source atom 中的内容重新表示，不能从译文推断 token；转换后必须恢复为逐字节相同的 reviewed candidate，否则失败。未变化 Unit 的 baseline 原 bytes 保持不变。

current-check 重新验证整个 bridge 和 derived baseline。Generation 编辑 current baseline，仍提交完整 protected raw response；process/validation/新 Snapshot 使用 current ID。replacement 不继承旧 A，必须独立 re-QC；finalization 通过所选 batch 的显式 successor lineage 验证历史 finalized predecessor，旧 finalization 不改写。

## 已生成输出恢复

复用既有 `generation-bundle recover`。successor batch ID/聚合 identity 改变不要求重做 exact compatible 的 unchanged Unit；同 ID/input、同 predecessor candidate 和原 finding semantics 才构成该授权的复用范围。恢复仍逐 expected filename、protected restore、机器校验，并拒绝不同有效 bytes、覆盖和已有正式导入状态；provenance 仍只由 import 建立。旧 replacement ID 的输出不会映射到新文件名，必须 missing。partial ZIP 与既有 staging/tar 路径共用同一逐 Unit preflight；ZIP 成员完整性错误保留为诊断，不改写原 ZIP。

## QC B/C/D 的 representation successor authority

同一个 schema-v1 replacement reopen 增加可选 `authority_source=quality-check`。它的 `replacement_context.quality_check` 精确绑定原 Snapshot manifest、QC results 及工程必要性 proof 的 path/SHA；不填 Surface、Preview、旧 reopen 或 finalization authority。原 Snapshot 可以尚未 finalized，但初审必须完整，所选项必须是 identity-matching 的 B/C/D，并有原始 finding。逐 Unit 保存原 rating、finding、完整 Snapshot candidate/validation/input identity 及原有 replacement mapping。工程 proof 的 `reason=protected-natural-language-unrepresentable`、rating、finding SHA 和完整 replacement 必须一致；没有真实 protected-input/Unit identity drift、scope 不符或已有相同 revision output 时拒绝。

CLI 复用 `quality-check surface-reopen`，新增 `--authority-source quality-check --previous-rating B|C|D --representation-proof <repository-path>`，同时要求 `--historical-documents`、原 `--previous-snapshot-id`、exact `--finding` 和 current `--unit-id`。不同 findings 按 stable index 重复传入。工程 proof 是工程必要性的声明及机器 mapping 证明，不提供任何译文或新语言结论；不得仅凭实现文件变化建立它。

reader、Bundle、retry、revision predecessor 与 QC 都复用已有 replacement 路径；新的 manifest feedback source 为 `quality_check_representation`。Generation Bundle 同时携带原 QC authority、工程 proof 和 frozen representations。新 Unit 的 revision 必须消费同一个原 B/C/D finding；不得继承旧 A/B 作为新结论，仍需新 validation 与独立 re-QC。旧 Surface / Preview reader 和无 replacement 的普通 B/C/D revision 保持原分支。

此工程实现不自动执行真实 reconciliation 或 export。SYS-01～08 已收口；当前 `chatgpt-zh-CN-046` 永久保持原 manifest/input、0 output、无 import/process。合法链为：046 immutable preserved → representation reconciliation → successor Unit representation → 消费同一 qc-014 B finding 的新 revision batch → validation → independent re-QC。不存在 same-batch refresh。receipt 建立后的完整命令统一维护于 [Retranslation Runbook 的 successor export 模板](RETRANSLATION_RUNBOOK.md#qc-bcd-representation-reconciliation--successor-exact-revision-export)。

### qc-014 successor export failure diagnosis

2026-10-16 的真实失败发生在 batch 写入之前；`data/retranslation-runs/zh-CN/chatgpt-zh-CN-047` 不存在，两次失败 attempt 均无 artifact mutation。receipt 的 quality-check authority 本身有效。未选择 package 的 CLI inventory 被原 replacement resolver 原样带入 historical Catalog，导致 QC reader 使用默认 Tour authorization namespace，遗漏 Learn/Docs 已封存的 A carry-forward。只读复现得到 effective=14、expected=49、historical_scope=0；显式选择 `learn-docs-v1` 后，同一 receipt 通过完整 gate。不能将该 14/49 解读为真正缺少 initial independent QC。

修复位于共享 `replacementResolution`：仅对 quality-check authority 且调用者无 scope 的分支，先验证 frozen source/package/registry/input 全部 replacement bindings，再从唯一 package descriptor 恢复完整 historical scope。export、Bundle 和 retry 使用同一个解析结果。显式 scope 不被覆盖，完整初审计数、原 finding/rating、engineering proof、candidate/validation/input 和 unconsumed-output gate 全部保留。没有新增 machine materialization step，也没有绕过初审或引入第二种 receipt。

修复后的真实只读 probe 在 unselected / `learn-docs-v1` 两种 inventory 均通过，原 receipt bytes 不变、047 仍不存在（两次 preflight 合计45.60s）。正式 export 仅在 `t.TempDir` synthetic frozen fixture 执行：完整 package 的五个 A 来自 sealed checkpoint，另一个 candidate 经过 revision 后分别得到 B/C/D，随后在显式 package 和 unselected inventory 导出 successor，并检查 Bundle 与 manifest 的 exact finding/rating/current ID。旧 ID、错误 Snapshot/receipt/finding、缺 engineering proof、A authority 和显式 partial scope 均 fail closed；真正缺初审的 ordinary revision 仍被初审 gate 拦截。CLI canonical command 通过与 `run` 相同的 global/subcommand parser 验证。本轮未进行真实 export、Generation 或任何正式语言 artifact mutation。

`docs/protected-representation-evidence/qc014-next-canonical-command.sh` 保留为上一阶段建立 receipt 的原命令证据；该动作已由维护者完成，不再次执行。当前唯一下一步是上述 Runbook 模板的 successor revision export，执行者仍为维护者 Local terminal。

本轮 targeted tests exact set（全部 PASS，不运行 package-wide suite）：

```text
internal/sitecontent:
  TestQCRepresentationSuccessorExportWithSealedCarry
  TestQualityCheckRepresentationReconciliation
  TestQCRepresentationExportReadonlyProbe (GO_TOUR_QC_RECONCILIATION_PROBE=1; read-only)
internal/i18n:
  TestOrdinaryRevisionStillRequiresCompleteInitialQC
  TestRevisionGenerationBundleOrdinaryRatings
  TestSurfaceReviewFindingCanExplicitlyReopenFinalizedAWithoutChangingHistory
  TestPreviewRevisionGenerationBundleInfersFrozenPackageScope
cmd/tour-i18n:
  TestQCRepresentationSuccessorCanonicalCommand
  TestParseRetranslationExportOptionsGenerator
```

B/C/D sealed-carry export fixture 最终27.58s；原 reconciliation 完整 fixture7.77s；四个 i18n regressions 合计1.430s；两个 CLI parser tests 合计0.017s。以上均为 focused 验证实测，不是完整 lifecycle 性能基准。
