===== INDEPENDENT RE-QC EVIDENCE =====

locale=zh-CN
review_id=20261021-zh-CN-learn-docs-qc-018-re-qc-page-001
rubric=translation-quality/v1
snapshot_id=learn-docs-v1-qc-018
previous_snapshot_id=learn-docs-v1-qc-017
working_set_kind=page

zip_sha256=a8e7ad4c83c26d3531fdb23b1c3d67121f19e2f7d65df4c853130bfdeb96de10
bundle_identity_sha256=c77795f401acba03e6d8a0652b3011be82277c08aba11cce65133a8856d8064d
input_gate=PASS

authorized_teaching_comment_slots=41
teaching_comment_slots_reviewed=41

------------------------------------------------
stable_index=2
unit_id=393fb67915a49876749590fd6480c9a3482597a9cebdd61e72c9a5f3d1449e2c
source_path=_content/doc/tutorial/add-a-test.html
rating=A
finding=none

------------------------------------------------
stable_index=12
unit_id=b49a0f38f79787a87a714c55b10e2987434ebdcd78c2c1cc0480e46523893493
source_path=_content/doc/tutorial/greetings-multiple-people.html
rating=A
finding=none

------------------------------------------------
stable_index=13
unit_id=66264496c6d846fefd6419e37c58df366152af07523cdd1f81088c8839f0e5ec
source_path=_content/doc/tutorial/handle-errors.html
rating=A
finding=none

------------------------------------------------
stable_index=17
unit_id=0895c1f2bf020716e82386c738f1b63ff49194250cf4cf254f9cf346a453fc10
source_path=_content/doc/tutorial/random-greeting.html
rating=A
finding=none

------------------------------------------------
stable_index=20
unit_id=d799614a9f1efd848505c615a88f2fb0f092ac22f743b3da042e12de1127fd8b
source_path=_content/doc/database/cancel-operations.md
rating=B
finding=正文中从“当一个 上下文 从外层 上下文 派生时”开始、至 QueryWithTimeout 示例说明结束的段落，多次在“上下文”前后保留不自然的空格（如“外层 上下文”“关联的 上下文”“该 上下文”“HTTP 请求的 上下文”），形成明显的中文排版/表达瑕疵，并与页面前文对 Context/context 的处理不协调。应只收口该局部自然语言的术语与空格表达，同时保持 queryCtx、ctx、http.Request.Context、HTTP/2、QueryWithTimeout 等技术 identity 和原有语义不变。

------------------------------------------------
stable_index=25
unit_id=872da6c618956d7ff25dbe8db7d898808b6a78fc1b91244ffcda0f59ce2b1983
source_path=_content/doc/database/open-handle.md
rating=C
finding=当前 Page 存在需要实际修订的发布质量问题，而非仅轻微润色。最明显的是“存储数据库凭据”段落：source 表达的是密钥管理应用保存凭据并提供 API，代码通过该 API 获取用于向 DBMS 认证的凭据；current candidate 的“并由它提供代码可用于 API获取凭据的接口，以便向 DBMS进行身份验证”语序和角色关系混乱，不能自然、准确地表达该技术关系。此外同 Page 多处存在明显的中文标点/空格断裂，例如开头的“工作
，简化了数据库访问
。”、“通常……连接 --；这项工作”、连接字符串段落中句号与正文脱离，以及若干中文标点前出现异常空白。修订应以这些具体局部为范围，恢复自然、准确的中文技术表达和标点，不改动 database/sql、sql.DB、API、DBMS、DSN、Connector、Go identifier、链接或代码语义。

------------------------------------------------
stable_index=27
unit_id=21946bff61d8f7c52c444edcd122ea398ba80574a8095c37befa936541a9cd4c
source_path=_content/doc/database/querying.md
rating=B
finding=页面技术含义总体正确，但仍有一组局部发布质量瑕疵需要收口：多处中文句号被拆到 inline technical token/上一行之后，产生“Row 。 ”、“false 。 ”及 rows.Close 段落中的类似异常空格/标点；两个函数表格中 source 的 reserved connections 被表达为“保留的专用连接”，措辞重复、生硬，与该连接概念的页面语境不够自然。应只修订这些局部措辞与中文标点/空格，保持 Query/QueryRow/Rows/Scan/Conn、SQL、DBMS、prepared statement 等技术语义及代码 identity 不变。

------------------------------------------------
stable_index=47
unit_id=a69694fb9c89d47440249dfd760d315586297f634d199b13532ac95cbced201f
source_path=_content/doc/security/vuln/database.md
rating=B
finding=完整 Page 中仍有两处可翻译的英文举例缩写直接残留在中文正文：修改时间说明中的“e.g，不能据此判断缓存是否失效”和 database_specific.url 说明中的“URL；e.g，可写作……”。这两处 e.g./e.g, 并非 identifier、schema 字段或必须保留的技术 token，在中文技术文档中形成明显语言残留。应仅修订这两处举例引导表达，保持 URL、database_specific.url、OSV schema、ID 及所有 API/JSON identity 不变。

------------------------------------------------
stable_index=48
unit_id=8eb5e9ea7af00232ebd029ae5dd0682a2c956167f69d073d0bf16de21668e689
source_path=_content/doc/security/vuln/editor.md
rating=A
finding=none

===== COUNTS =====
A=5
B=3
C=1
D=0
REVIEWED_UNITS=9
MISSING=0
EXTRA=0

===== FINAL =====
RESULT=FAILED
LOCALE=zh-CN
REVIEW_ID=20261021-zh-CN-learn-docs-qc-018-re-qc-page-001
SNAPSHOT_ID=learn-docs-v1-qc-018
PREVIOUS_SNAPSHOT_ID=learn-docs-v1-qc-017
WORKING_SET_KIND=page
FORMAL_UNITS=9
REVIEWED_UNITS=9
A=5
B=3
C=1
D=0
MISSING=0
EXTRA=0
INPUT_GATE=PASS
INDEPENDENT_REVIEW=yes
REPLACEMENT_GENERATED=no
REPOSITORY_MUTATION=none
REMOTE_CALLS_USED=0
UNRESOLVED_BLOCKER=4 non-A Page TranslationUnits at stable_index 20,25,27,47 require exact revision and successor independent re-QC
STOP=before-quality-check-record
